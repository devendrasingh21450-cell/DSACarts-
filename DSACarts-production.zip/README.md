# DSACarts — Production-ready foundation

This is a real (not demo-only) Cloudflare Worker + D1 project with:
- Public product-price comparison
- Private `/admin` dashboard
- Google OAuth sign-in
- Server-side session signing
- D1 database for products/prices
- Old-price fallback: prices remain until updated
- Automatic "Data may be delayed" label after 3 days
- Store-by-store comparison
- No flight section

## Required one-time deployment setup

1. Install Cloudflare Wrangler and log in.
2. Create a D1 database named `dsacarts-db` and put its ID into `wrangler.toml`.
3. Run the SQL in `schema.sql` against that D1 database.
4. In Google Cloud Console, create OAuth 2.0 Web credentials.
5. Add this Authorized redirect URI:
   `https://YOUR-DOMAIN/auth/callback`
6. Put your Google client ID and authorized admin email in `wrangler.toml`.
7. Set secrets (never commit them):
   `wrangler secret put GOOGLE_CLIENT_SECRET`
   `wrangler secret put SESSION_SECRET`
8. Deploy with Wrangler.

## Important
Google OAuth credentials and SESSION_SECRET are deliberately NOT included.
The Google account allowed into `/admin` is controlled by ADMIN_GOOGLE_EMAIL.
Do not put secrets in HTML/JavaScript.

This project does not automatically collect prices from Amazon/Flipkart/etc.
Prices are entered through the secure admin panel and should be checked against
the relevant store before publication. Store names/links and any affiliate
relationship must follow the stores' applicable terms.

## Routes
/           public comparison
/admin      admin dashboard
/auth/google
/auth/callback
/api/products
/api/admin/products

