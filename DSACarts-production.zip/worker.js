const SESSION_COOKIE = "dsa_session";
const enc = new TextEncoder();

function b64u(bytes){return btoa(String.fromCharCode(...bytes)).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}
function b64ud(s){s=s.replace(/-/g,"+").replace(/_/g,"/");while(s.length%4)s+="=";return Uint8Array.from(atob(s),c=>c.charCodeAt(0))}
async function sign(value, secret){
 const key=await crypto.subtle.importKey("raw",enc.encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign","verify"]);
 return b64u(new Uint8Array(await crypto.subtle.sign("HMAC",key,enc.encode(value))));
}
async function makeSession(email,env){
 const payload=b64u(enc.encode(JSON.stringify({email,exp:Date.now()+86400000})));
 return payload+"."+await sign(payload,env.SESSION_SECRET);
}
async function getSession(req,env){
 const c=req.headers.get("Cookie")||"", m=c.match(new RegExp(SESSION_COOKIE+"=([^;]+)")); if(!m)return null;
 const [p,s]=m[1].split("."); if(!p||!s)return null;
 const ok=await sign(p,env.SESSION_SECRET); if(ok!==s)return null;
 try{const x=JSON.parse(new TextDecoder().decode(b64ud(p))); return x.exp>Date.now()?x:null}catch{return null}
}
function htmlHeaders(){return {"content-type":"text/html;charset=UTF-8"}}
async function json(r){return new Response(JSON.stringify(r),{headers:{"content-type":"application/json"}})}
async function requireAdmin(req,env){const s=await getSession(req,env);return s&&s.email.toLowerCase()===env.ADMIN_GOOGLE_EMAIL.toLowerCase()?s:null}

export default {
 async fetch(req,env){
  const u=new URL(req.url);
  if(u.pathname==="/") return new Response(await env.ASSETS.fetch(new Request(new URL("/index.html",u))),{headers:htmlHeaders()});
  if(u.pathname==="/admin") return env.ASSETS.fetch(new Request(new URL("/admin.html",u)));

  if(u.pathname==="/api/me"){const s=await getSession(req,env);return json(s?{authenticated:true,email:s.email}:{authenticated:false})}

  if(u.pathname==="/auth/google"){
   const state=crypto.randomUUID();
   const cb=`${u.origin}/auth/callback`;
   const params=new URLSearchParams({client_id:env.GOOGLE_CLIENT_ID,redirect_uri:cb,response_type:"code",scope:"openid email profile",state,access_type:"online",prompt:"select_account"});
   return Response.redirect("https://accounts.google.com/o/oauth2/v2/auth?"+params,302);
  }

  if(u.pathname==="/auth/callback"){
   const code=u.searchParams.get("code"); if(!code)return new Response("Missing code",{status:400});
   const cb=`${u.origin}/auth/callback`;
   const token=await fetch("https://oauth2.googleapis.com/token",{method:"POST",headers:{"content-type":"application/x-www-form-urlencoded"},body:new URLSearchParams({code,client_id:env.GOOGLE_CLIENT_ID,client_secret:env.GOOGLE_CLIENT_SECRET,redirect_uri:cb,grant_type:"authorization_code"})});
   const td=await token.json(); if(!td.access_token)return new Response("Google sign-in failed",{status:401});
   const info=await fetch("https://openidconnect.googleapis.com/v1/userinfo",{headers:{Authorization:`Bearer ${td.access_token}`}});
   const profile=await info.json();
   if(!profile.email||profile.email.toLowerCase()!==env.ADMIN_GOOGLE_EMAIL.toLowerCase())return new Response("This Google account is not authorized.",{status:403});
   const session=await makeSession(profile.email,env);
   return new Response(null,{status:302,headers:{Location:"/admin", "Set-Cookie":`${SESSION_COOKIE}=${session}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=86400`}});
  }

  if(u.pathname==="/auth/logout")return new Response(null,{status:302,headers:{Location:"/", "Set-Cookie":`${SESSION_COOKIE}=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0`}});

  if(u.pathname==="/api/products"){
   const q=(u.searchParams.get("q")||"").toLowerCase();
   const products=await env.DB.prepare("SELECT id,name FROM products WHERE lower(name) LIKE ? ORDER BY name").bind(`%${q}%`).all();
   const out=[];
   for(const p of products.results){
    const rows=await env.DB.prepare("SELECT store,price,url,updated_at FROM prices WHERE product_id=? ORDER BY store").bind(p.id).all();
    out.push({name:p.name,prices:rows.results.map(x=>({...x,stale:!x.updated_at||Date.now()-new Date(x.updated_at).getTime()>3*86400000}))});
   }
   return json(out);
  }

  if(u.pathname==="/api/admin/products"&&req.method==="POST"){
   if(!await requireAdmin(req,env))return new Response("Unauthorized",{status:401});
   const b=await req.json(); if(!b.name||!b.store||b.price==null)return new Response("Missing fields",{status:400});
   let p=await env.DB.prepare("SELECT id FROM products WHERE lower(name)=lower(?)").bind(b.name).first();
   if(!p){await env.DB.prepare("INSERT INTO products(name) VALUES(?)").bind(b.name).run();p=await env.DB.prepare("SELECT id FROM products WHERE lower(name)=lower(?)").bind(b.name).first();}
   await env.DB.prepare("INSERT INTO prices(product_id,store,price,url,updated_at) VALUES(?,?,?,?,datetime('now')) ON CONFLICT(product_id,store) DO UPDATE SET price=excluded.price,url=excluded.url,updated_at=excluded.updated_at").bind(p.id,b.store,b.price,b.url||"").run();
   return json({ok:true});
  }
  return new Response("Not found",{status:404});
 }
}