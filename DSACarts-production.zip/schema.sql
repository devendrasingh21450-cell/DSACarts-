CREATE TABLE products (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL UNIQUE
);
CREATE TABLE prices (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 product_id INTEGER NOT NULL,
 store TEXT NOT NULL,
 price REAL NOT NULL,
 url TEXT,
 updated_at TEXT,
 UNIQUE(product_id, store),
 FOREIGN KEY(product_id) REFERENCES products(id)
);
CREATE INDEX idx_products_name ON products(name);